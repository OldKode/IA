/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a_hater;

/**
 *
 * @author joao.lslima1
 */
public class No {
    private int X; //X da Matriz
    private int Y; //Y da Matriz
    private int F; //Valor
    private int G; //Custo
    private int H; //Euristica
    private No parent; //Nó Pai

    /**
     * @return the X
     */
    public int getX() {
        return X;
    }

    /**
     * @param X the X to set
     */
    public void setX(int X) {
        this.X = X;
    }

    /**
     * @return the Y
     */
    public int getY() {
        return Y;
    }

    /**
     * @param Y the Y to set
     */
    public void setY(int Y) {
        this.Y = Y;
    }

    /**
     * @return the F
     */
    public int getF() {
        return F;
    }

    /**
     * @param F the F to set
     */
    public void setF(int F) {
        this.F = F;
    }

    /**
     * @return the G
     */
    public int getG() {
        return G;
    }

    /**
     * @param G the G to set
     */
    public void setG(int G) {
        this.G = G;
    }

    /**
     * @return the H
     */
    public int getH() {
        return H;
    }

    /**
     * @param H the H to set
     */
    public void setH(int H) {
        this.H = H;
    }

    /**
     * @return the parent
     */
    public No getParent() {
        return parent;
    }

    /**
     * @param parent the parent to set
     */
    public void setParent(No parent) {
        this.parent = parent;
    }
    
}
