/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a_hater;

import java.util.ArrayList;

/**
 *
 * @author joao.lslima1
 */
public class Estrela {
    ArrayList<No> aberta;
    ArrayList<No> fechada;
    
    public Estrela(){
        aberta.clear();
        fechada.clear();               
    }
    
    public boolean busca(No inicio, No destino){
        aberta.clear();
        fechada.clear(); 
        aberta.add(inicio);
        
        while(!aberta.isEmpty()){
            fechada.add(aberta.);
            
        }
        
        return false;
    }
    
}
